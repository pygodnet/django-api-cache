from django_api_cache.func_demo import api_cache

__all__ = ['api_cache']
